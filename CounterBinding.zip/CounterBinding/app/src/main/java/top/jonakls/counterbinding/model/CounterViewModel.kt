package top.jonakls.counterbinding.model

import androidx.databinding.ObservableField
import androidx.lifecycle.ViewModel

class CounterViewModel : ViewModel() {

    private val counter: ObservableField<String> = ObservableField<String>("0")

    fun increment() {
        var value = Integer.parseInt(this.rawValue())
        value++
        this.counter.set(value.toString())
    }

    fun decrement() {
        var value = Integer.parseInt(this.rawValue())
        value--
        this.counter.set(value.toString())
    }

    private fun rawValue(): String {
        return counter.get() ?: return "0"
    }

    fun value(): ObservableField<String> {
        return this.counter
    }
}